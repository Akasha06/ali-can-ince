// ===== Helpers =====
const $ = (sel, root=document) => root.querySelector(sel);
const $$ = (sel, root=document) => Array.from(root.querySelectorAll(sel));

const i18n = {
  tr: {
    nav_about: "Hakkımda",
    nav_experience: "Deneyim",
    nav_projects: "Projeler",
    nav_skills: "Yetkinlikler",
    nav_contact: "İletişim",
    theme: "Tema",
    pill: "Service Operations • Performance Management • Process Excellence",
    hero_title_1: "Operasyonları",
    hero_title_2: "standartlaştırır, ölçer ve",
    hero_title_3: "ölçeklenebilir hale getiririm.",
    hero_lead: "KPI tasarımı, raporlama mimarisi ve otomasyon ile saha ve ofis operasyonlarını tek bir yönetim diline çeviririm; karar alma hızını ve kaliteyi artırırım.",
    cta_projects: "Projeleri Gör",
    cta_contact: "İletişime Geç",
    cta_cv: "CV İndir",
    m_years: "Yıl deneyim",
    m_focus: "Odak: Operasyon Mükemmelliği, Analitik, Otomasyon",
    m_stack: "Raporlama ve otomasyon",
    subname: "(Can)",
    role: "Service & Operations Optimization Specialist",
    chip1: "KPI & Reporting",
    chip2: "Dashboards",
    chip3: "Automation",
    chip4: "Stakeholder Mgmt",    about_title: "Hakkımda",
    about_sub: "Operasyonel karmaşıklığı sadeleştirir; ölçülebilir, denetlenebilir ve sürdürülebilir süreçlere dönüştürürüm.",
    about_h3_1: "Ne yaparım?",
    about_p1: "Servis operasyonlarında KPI’ları tanımlar; iş emirleri, saha performansı, parça/işçilik süreçleri ve kalite metriklerini tek bir raporlama sisteminde birleştiririm. Excel/VBA ve Python otomasyonlarıyla manuel işi azaltır, hata riskini düşürür ve operasyon hızını artırırım.",
    about_h3_2: "Nasıl değer üretirim?",
    about_li1: "Saha + ofis akışlarını tek yönetim panelinde görünür kılarım.",
    about_li2: "Raporlama standartlarını kurar, sürdürülebilir hale getiririm.",
    about_li3: "Teknik ekip, servisler ve yöneticiler arasında net iletişim kurarım.",
    about_li4: "Süreç iyileştirme ve maliyet azaltma fırsatlarını sayıya dökerim.",
    callout_title: "Kısa özet",
    callout_body: "Veri → içgörü → aksiyon zincirini kurarım. Operasyonun sahada ve raporda aynı doğrulukla çalışmasını hedefler, standardı korurum.",
    exp_title: "Deneyim",
    exp_sub: "Görev tanımlarından çok; süreç, kalite ve performans çıktısı odaklı bir özet.",
    exp_role_1: "After Sales • Service Operations & Optimization",
    exp_org_1: "Samsung Electronics • Türkiye",
    exp_date_2: "Çapraz projeler",
    exp_role_2: "Automation & Reporting",
    exp_org_2: "Excel/VBA • Python • Web dashboards",
    exp1_li1: "KPI tasarımı, dashboard ve otomasyon ile günlük/haftalık operasyon takibi.",
    exp1_li2: "Teknisyen performansı, iş emri statüleri ve kalite metriklerinde raporlama standartları.",
    exp1_li3: "Parça/işçilik süreçlerinde verimlilik ve maliyet iyileştirme çalışmaları.",
    exp1_li4: "Çok paydaşlı iletişim: saha ekipleri, servis partnerleri, bölge yöneticileri.",
    exp2_li1: "Excel şablonları, veri doğrulama, sayfa koruma ve kullanıcı dostu giriş ekranları.",
    exp2_li2: "Python ile veri toplama/temizleme, otomatik rapor üretimi, web otomasyonları.",
    exp2_li3: "Power BI benzeri HTML dashboard tasarımları ve filtreli raporlama mantığı.",
    proj_title: "Seçilmiş Projeler",
    proj_sub: "Problem → yaklaşım → çıktı formatında. Gerektiğinde detay / metrik eklenebilir.",
    p1_title: "İskonto Süreci / Karlılık Modeli",
    p1_stack: "Excel • İş kuralları • Eğitim dokümanı",
    p1_desc: "Parça kârlılığına göre iskonto oranlarının otomatik hesaplandığı, standart işçilik uygulamasıyla birlikte çalışan şablon ve raporlama düzeni.",
    p1_li1: "Hata payını azaltan kontrol alanları",
    p1_li2: "Şef ve müdür seviyesinde anlaşılır rapor",
    p1_li3: "Eğitim sunumu + kullanım kılavuzu",
    p2_title: "Teknisyen KPI Dashboard",
    p2_stack: "Excel • Pivot • Filtreli görünüm",
    p2_desc: "Servis bazlı odakla; gün/hafta/ay kırılımında performans, iş emri statüleri ve hedef takibini tek ekranda birleştiren dashboard.",
    p2_li1: "Tek ekran yönetim paneli",
    p2_li2: "Yetkilendirme ve hücre/sayfa koruma",
    p2_li3: "Pivot raporlama şablonları",
    p3_title: "Otomasyon: Veri Toplama & Raporlama",
    p3_stack: "Python • Selenium • Pandas",
    p3_desc: "Veri çekme/temizleme ve rapor üretimini otomatikleştirerek manuel iş yükünü azaltan, standart çıktılar üreten araç seti.",
    p3_li1: "Tek tuş rapor üretimi",
    p3_li2: "Standart çıktı formatları",
    p3_li3: "Hata yönetimi ve loglama",    p5_title: "Süreç Standardizasyonu & Kalite Yönetimi",
    p5_stack: "Prosedür • Eğitim • İletişim",
    p5_desc: "Değişim/onarım prosedürleri, kayıt açıklama standartları ve saha iletişim şablonları ile kalite ve uyumun güçlendirilmesi.",
    p5_li1: "Süreç hatalarının azaltılması",
    p5_li2: "Ekipler arası ortak dil",
    p5_li3: "Eğitim dokümanları",
    p6_title: "Sistem Tutarlılığı / Veri Uyuşmazlığı Analizi",
    p6_stack: "Kayıt eşleşmesi • Operasyon riski",
    p6_desc: "İki farklı sistem arasında statü senkronizasyonu probleminde; riskleri ortaya çıkaran, örnek kayıt listesiyle çözüm talep eden analiz.",
    p6_li1: "Operasyonel sürdürülebilirlik",
    p6_li2: "Mükerrer aksiyon riskini azaltma",
    p6_li3: "İyileştirme önerileri",
    skills_title: "Yetkinlikler",
    skills_sub: "Operasyon + veri + iletişim üçgeninde güçlü bir profil.",
    s1_title: "Operations & Process",
    s1_li1: "Service network management",
    s1_li2: "KPI design & governance",
    s1_li3: "Cost saving & efficiency models",
    s1_li4: "Quality & compliance standardization",
    s2_title: "Data & Automation",
    s2_li1: "Excel (advanced) • Pivot • Power Query",
    s2_li2: "VBA macros • Templates • Protection",
    s2_li3: "Python • Pandas • Selenium",
    s2_li4: "Automated reporting pipelines",
    s3_title: "Communication",
    s3_li1: "Stakeholder management",
    s3_li2: "Clear escalation & follow-up",
    s3_li3: "Training docs & presentations",
    s3_li4: "Operational storytelling with data",
    faq_q1: "Bu siteyi nasıl yayına alırım?",
    faq_a1: "En kolay yöntem: GitHub Pages. Dosyaları bir repo’ya yükle, Settings → Pages → Deploy. Alternatif: Cloudflare Pages.",
    faq_q2: "Fotoğrafımı nasıl ekleyeceğim?",
    faq_a2: "Kendi fotoğrafını assets/hero.jpg adıyla kopyala. Aynı ölçüde otomatik sığar.",
    faq_q3: "CV PDF nerede?",
    faq_a3: "assets/ali-can-ince-cv.pdf dosyası şu an “placeholder”. CV’ni bana metin olarak verdiğinde ATS uyumlu PDF’yi üretip ekleyebilirim.",
    contact_title: "İletişim",
    contact_sub: "İş birlikleri, proje görüşmeleri veya rol fırsatları için ulaşabilirsin.",
    contact_h3: "Hızlı İletişim",
    contact_p: "Aşağıdaki alanları doldurup kopyalayarak e‑posta/LinkedIn üzerinden gönderebilirsin. (Bu statik sitede form gönderimi yoktur.)",
    f_name: "Ad Soyad",
    f_email: "E‑posta",
    f_msg: "Mesaj",
    copy_btn: "Mesajı Kopyala",
    contact_links: "Bağlantılar",
    link_linkedin: "LinkedIn (ekle)",
    link_github: "GitHub (opsiyonel)",
    link_email: "E‑posta (güncelle)",
    contact_note: "Not: Bağlantıları güncellemek için index.html içinde “#” ile başlayan href alanlarını değiştirmen yeterli.",
    footer_right: "Designed & built for a data-driven operations profile."
  },
  en: {
    nav_about: "About",
    nav_experience: "Experience",
    nav_projects: "Projects",
    nav_skills: "Skills",
    nav_contact: "Contact",
    theme: "Theme",
    pill: "Service Operations • Performance Management • Process Excellence",
    hero_title_1: "I standardize operations",
    hero_title_2: "make them measurable, and",
    hero_title_3: "run them at scale.",
    hero_lead: "I turn field and office workflows into one management language through KPI design, reporting architecture, and automation—improving decision speed and quality.",
    cta_projects: "View Projects",
    cta_contact: "Get in Touch",
    cta_cv: "Download CV",
    m_years: "Years experience",
    m_focus: "Focus: Operations, Analytics, Automation",
    m_stack: "Reporting & automation",
    subname: "(Can)",
    role: "Service & Operations Optimization Specialist",
    chip1: "KPI & Reporting",
    chip2: "Dashboards",
    chip3: "Automation",
    chip4: "Stakeholder Mgmt",    about_title: "About",
    about_sub: "I simplify operational complexity and build measurable, auditable, and sustainable systems.",
    about_h3_1: "What I do",
    about_p1: "I define KPIs for service operations and consolidate job orders, field performance, parts/labor workflows, and quality metrics into a single reporting system. With Excel/VBA and Python automation, I reduce manual effort, lower error risk, and increase operational speed.",
    about_h3_2: "How I create value",
    about_li1: "Make field + office flows visible in a single management panel.",
    about_li2: "Build reporting standards and make them sustainable.",
    about_li3: "Create clear communication across technical teams, partners, and leadership.",
    about_li4: "Quantify improvement and cost-saving opportunities.",
    callout_title: "In short",
    callout_body: "I build the chain from data → insight → action, ensuring operations work consistently both in the field and on the report.",
    exp_title: "Experience",
    exp_sub: "A results-first summary focused on process, quality, and performance outcomes.",
    exp_role_1: "After Sales • Service Operations & Optimization",
    exp_org_1: "Samsung Electronics • Türkiye",
    exp_date_2: "Cross-functional work",
    exp_role_2: "Automation & Reporting",
    exp_org_2: "Excel/VBA • Python • Web dashboards",
    exp1_li1: "Daily/weekly operational tracking via KPI design, dashboards, and automation.",
    exp1_li2: "Reporting standards for technician performance, job order statuses, and quality metrics.",
    exp1_li3: "Efficiency and cost-improvement initiatives in parts/labor processes.",
    exp1_li4: "Multi-stakeholder coordination: field teams, service partners, regional leadership.",
    exp2_li1: "Excel templates, validation, page protection, and user-friendly inputs.",
    exp2_li2: "Python data collection/cleaning, automated report generation, web automations.",
    exp2_li3: "Power BI-like HTML dashboards with synchronized filtering logic.",
    proj_title: "Selected Projects",
    proj_sub: "Structured as Problem → Approach → Outcome. (Metrics can be added when needed.)",
    p1_title: "Discount Process / Profitability Model",
    p1_stack: "Excel • Business rules • Training doc",
    p1_desc: "A standardized template that calculates discount rates based on parts profitability, aligned with labor policy and reporting.",
    p1_li1: "Guardrails that reduce error",
    p1_li2: "Manager-ready reporting",
    p1_li3: "Training deck + user guide",
    p2_title: "Technician KPI Dashboard",
    p2_stack: "Excel • Pivot • Filtered views",
    p2_desc: "A service-based dashboard combining performance, job order statuses, and target tracking across daily/weekly/monthly cuts.",
    p2_li1: "Single-screen management panel",
    p2_li2: "Authorization and sheet/cell protection",
    p2_li3: "Pivot reporting templates",
    p3_title: "Automation: Data Collection & Reporting",
    p3_stack: "Python • Selenium • Pandas",
    p3_desc: "A toolkit that automates data extraction from web screens, cleaning, and Excel report generation to reduce manual workload.",
    p3_li1: "One-click reporting",
    p3_li2: "Standardized outputs",
    p3_li3: "Error handling & logging",    p5_title: "Process Standardization & Quality Management",
    p5_stack: "Procedures • Training • Communication",
    p5_desc: "Strengthening compliance via clear procedures, documentation standards, and field communication templates.",
    p5_li1: "Reduced process errors",
    p5_li2: "Shared language across teams",
    p5_li3: "Training materials",
    p6_title: "System Consistency / Data Mismatch Analysis",
    p6_stack: "Record matching • Operational risk",
    p6_desc: "Analysis highlighting operational risk when statuses do not synchronize across systems, supported by sample record lists and requests for a permanent fix.",
    p6_li1: "Operational sustainability",
    p6_li2: "Reduced duplicate-action risk",
    p6_li3: "Improvement recommendations",
    skills_title: "Skills",
    skills_sub: "Strong across operations + data + communication.",
    s1_title: "Operations & Process",
    s1_li1: "Service network management",
    s1_li2: "KPI design & governance",
    s1_li3: "Cost saving & efficiency models",
    s1_li4: "Quality & compliance standardization",
    s2_title: "Data & Automation",
    s2_li1: "Excel (advanced) • Pivot • Power Query",
    s2_li2: "VBA macros • Templates • Protection",
    s2_li3: "Python • Pandas • Selenium",
    s2_li4: "Automated reporting pipelines",
    s3_title: "Communication",
    s3_li1: "Stakeholder management",
    s3_li2: "Clear escalation & follow-up",
    s3_li3: "Training docs & presentations",
    s3_li4: "Operational storytelling with data",
    faq_q1: "How do I publish this site?",
    faq_a1: "Easiest: GitHub Pages. Upload files to a repo, then Settings → Pages → Deploy. Alternative: Cloudflare Pages.",
    faq_q2: "How do I add my photo?",
    faq_a2: "Replace assets/hero.jpg with your own photo using the same filename.",
    faq_q3: "Where is the CV PDF?",
    faq_a3: "assets/ali-can-ince-cv.pdf is currently a placeholder. If you share your CV text, I can generate an ATS-friendly PDF and embed it.",
    contact_title: "Contact",
    contact_sub: "Reach out for collaboration, projects, or role opportunities.",
    contact_h3: "Quick message",
    contact_p: "Fill this and copy it to email/LinkedIn. (This static site does not submit forms.)",
    f_name: "Name",
    f_email: "Email",
    f_msg: "Message",
    copy_btn: "Copy Message",
    contact_links: "Links",
    link_linkedin: "LinkedIn (add)",
    link_github: "GitHub (optional)",
    link_email: "Email (update)",
    contact_note: "Note: To update links, replace href values that currently start with '#'.",
    footer_right: "Designed & built for a data-driven operations profile."
  }
};

// ===== Theme =====
const THEME_KEY = "can_portfolio_theme";
const LANG_KEY = "can_portfolio_lang";

function applyTheme(theme){
  document.documentElement.setAttribute("data-theme", theme);
  localStorage.setItem(THEME_KEY, theme);
}

function toggleTheme(){
  const current = document.documentElement.getAttribute("data-theme") || "dark";
  applyTheme(current === "dark" ? "light" : "dark");
}

// ===== Language =====
function applyLang(lang){
  document.documentElement.lang = lang === "en" ? "en" : "tr";
  $("#langLabel").textContent = (lang === "en") ? "EN" : "TR";
  localStorage.setItem(LANG_KEY, lang);

  $$("[data-i18n]").forEach(el => {
    const key = el.getAttribute("data-i18n");
    const value = (i18n[lang] && i18n[lang][key]) ? i18n[lang][key] : null;
    if (value !== null) el.innerHTML = value;
  });
}

// ===== Mobile nav =====
function setupMobileNav(){
  const burger = $("#burger");
  const mobileNav = $("#mobileNav");
  burger?.addEventListener("click", () => {
    mobileNav.classList.toggle("open");
  });
  // close on click
  $$("#mobileNav a").forEach(a => a.addEventListener("click", () => mobileNav.classList.remove("open")));
}

// ===== Copy message =====
function setupCopy(){
  const btn = $("#copyMsg");
  const hint = $("#copyHint");
  btn?.addEventListener("click", async () => {
    const inputs = $$(".formlike input, .formlike textarea");
    const name = inputs[0]?.value?.trim() || "";
    const email = inputs[1]?.value?.trim() || "";
    const msg = inputs[2]?.value?.trim() || "";
    const text = `Name: ${name}\nEmail: ${email}\n\nMessage:\n${msg}`;
    try{
      await navigator.clipboard.writeText(text);
      hint.textContent = "Kopyalandı. Şimdi e‑posta/LinkedIn’e yapıştırabilirsin.";
      setTimeout(() => hint.textContent = "", 2500);
    }catch(e){
      hint.textContent = "Kopyalama başarısız. Manuel kopyalayabilirsin.";
      setTimeout(() => hint.textContent = "", 2500);
    }
  });
}

// ===== Init =====
(function init(){
  // year
  $("#year").textContent = new Date().getFullYear();

  // theme
  const savedTheme = localStorage.getItem(THEME_KEY) || "dark";
  applyTheme(savedTheme);
  $("#themeBtn")?.addEventListener("click", toggleTheme);

  // lang
  const savedLang = localStorage.getItem(LANG_KEY) || "tr";
  applyLang(savedLang);
  $("#langBtn")?.addEventListener("click", () => {
    const next = (localStorage.getItem(LANG_KEY) || "tr") === "tr" ? "en" : "tr";
    applyLang(next);
  });

  setupMobileNav();
  setupCopy();
})();
